package heroes

class Slideshow(val slides: List<Slide>) {


}
